Note
====
Theme Information	
Neu Proflie, is created to suit a profissional Webdesigner, Web UI Developer, UX/UI Developer, Programmer's portfolio. This is a clean responsive web design template you can use for personal portfolio�s websites to show case your work and resume and more. This template is built on Bootstrap framework which give flexibilty to customeise the theme easly as per the user requirements. All latest technology HTML5 CSS3, jQuery and bootstrap.

Key features
Twitter Bootstrap 3.1.1
Valid HTML5 & CSS3
FontAwesome Icons
Portfolio and Pricing Table
Gmap
Contact Form

Responsive, Bootstrap Mobile First Web Template
 
Author URI: http://webthemez.com/

License: Free to use for personal and commercial, but you need to place back link in the bottom of the template(Template by: webthemez.com).


Credits
=======
Framework  http://getbootstrap.com
Images	Unsplash (http://unsplash.com - CC0 licensed) 
Icons	Font Awesome (http://fortawesome.github.com/Font-Awesome/)
Other	html5shiv.js (@afarkas @jdalton @jon_neal @rem)

